odoo.define('theme_ninja_quiz.main', function (require) {
    'use strict';

    const publicWidget = require('web.public.widget');

    publicWidget.registry.NinjaQuiz = publicWidget.Widget.extend({
        selector: '.ninja-quiz-pin-form',
        events: {
            'submit': '_onSubmit',
        },

        _onSubmit: function (ev) {
            ev.preventDefault();
            const pin = this.$el.find('input[name="pin"]').val();
            if (pin && /^\d{6}$/.test(pin)) {
                window.location.href = `/ninja-quiz/pin-display?pin=${pin}`;
            } else {
                this.$el.find('input[name="pin"]').addClass('is-invalid');
                this.$el.find('input[name="pin"]').focus();
            }
        },
    });

    return publicWidget.registry.NinjaQuiz;
});