# -*- coding: utf-8 -*-
{
    'name': 'Theme Ninja Quiz',
    'version': '1.0',
    'author': 'Tu Nombre',
    'website': 'https://tusitio.com',
    'summary': 'Theme estilo Kahoot para Odoo 17',
    'description': """
        Theme para Odoo 17 que emula la pantalla de entrada de Kahoot
    """,
    'category': 'Theme',
    'depends': ['website'],
    'data': [
        'templates/homepage.xml',
        'templates/pin_display.xml',
        'views/snippets.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'theme_ninja_quiz/static/src/scss/variables.scss',
            'theme_ninja_quiz/static/src/scss/styles.scss',
            'theme_ninja_quiz/static/src/js/ninja_quiz.js',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}