from odoo import http
from odoo.http import request

class NinjaQuizController(http.Controller):
    @http.route('/play', type='http', auth='public', website=True)
    def play_page(self, **kwargs):
        return request.render('theme_ninja_quiz.play_template', {})
