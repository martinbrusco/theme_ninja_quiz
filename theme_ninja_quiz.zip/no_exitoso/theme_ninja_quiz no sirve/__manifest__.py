{
    'name': 'Theme Ninja Quiz',
    'description': 'Tema personalizado para emular el estilo de Kahoot',
    'summary': 'Un tema básico que emula el diseño de Kahoot',
    'version': '1.0',
    'author': 'Tu Nombre o Empresa',
    'website': 'https://tuweb.com',
    'category': 'Theme/Creative',
    'license': 'LGPL-3',
    'depends': ['website'],
    'data': [
        'views/assets.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'theme_ninja_quiz/static/src/css/theme_ninja_quiz.css',
        ],
    },
    'images': [],
    'live_test_url': '',
    'theme': True,
    'application': False,
    'installable': True,
    'auto_install': False,
    'sequence': 1
}
