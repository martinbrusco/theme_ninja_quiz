# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class NinjaQuiz(http.Controller):
    @http.route('/ninja_quiz', type='http', auth="public", website=True)
    def index(self, **kw):
        return request.render('theme_ninja_quiz.index')

    @http.route('/ninja_quiz/submit_pin', type='http', auth="public", website=True, methods=['POST'])
    def submit_pin(self, pin, **kw):
        return request.render('theme_ninja_quiz.display_pin', {'pin': pin})