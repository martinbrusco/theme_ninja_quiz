# -*- coding: utf-8 -*-
{
    'name': "Ninja Quiz Theme",
    'summary': """
        Tema para emular la pantalla inicial de Kahoot para ingresar un PIN de juego.
    """,
    'description': """
        Este tema proporciona una interfaz simple con un campo de entrada para un PIN de juego y un botón para continuar.
    """,
    'version': '1.0',
    'author': "Tu Nombre",
    'website': "http://www.tuweb.com",
    'category': 'Theme/Creative',
    'depends': ['web'],  # Dependencia del módulo web base
    'data': [
        'views/templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'theme_ninja_quiz/static/src/css/style.css', # Opcional: para estilos personalizados
        ],
    },
    'license': 'LGPL-3',
}