from odoo import http
from odoo.http import request

class NinjaQuizController(http.Controller):

    @http.route('/play', type='http', auth='public', website=True)
    def play_quiz(self, **kwargs):
        return request.render('theme_ninja_quiz.template_play_quiz', {})
