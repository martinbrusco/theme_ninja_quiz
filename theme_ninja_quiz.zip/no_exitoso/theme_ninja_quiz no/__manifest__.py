{
    'name': 'Theme Ninja Quiz',
    'description': 'Tema personalizado para emular el estilo de Kahoot',
    'category': 'Theme/Creative',
    'version': '1.0',
    'author': 'Tu Nombre o Empresa',
    'website': 'https://tuweb.com',
    'depends': ['website'],
    'data': [
        'views/play_template.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'theme_ninja_quiz/static/src/css/theme_ninja_quiz.css',
        ],
    },
    'license': 'LGPL-3',
    'application': False,
    'installable': True,
    'auto_install': False,
    'sequence': 1,
    'summary': 'Un tema básico que emula el diseño de Kahoot',
    'images': [],
    'live_test_url': '',
    'theme': True
}
