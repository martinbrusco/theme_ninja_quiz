{
    'name': 'Theme Ninja Quiz',
    'version': '1.0',
    'summary': 'Quiz game X',
    'category': 'Theme/Frontend',
    'description': 'Un theme personalizado para jugar al quiz ninja.',
    'author': 'Tu Nombre o Empresa',
    'website': 'https://tusitio.com',
    'depends': ['website'],  # Asegúrate de incluir esta dependencia
    'data': [
        'views/quiz_templates.xml',  # Archivo XML con las vistas
    ],
    'assets': {
        'web.assets_frontend': [
            'theme_ninja_quiz/static/src/css/style.css',  # Incluye tu CSS aquí
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': False,
}