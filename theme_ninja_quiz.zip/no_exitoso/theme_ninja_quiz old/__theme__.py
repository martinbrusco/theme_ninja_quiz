{
    "assets": [
        "theme_ninja_quiz/static/src/css/style.css",  # Incluye tus activos aquí
    ],
    "snippet_lists": [],  # Si no tienes snippets personalizados, deja esta lista vacía
}